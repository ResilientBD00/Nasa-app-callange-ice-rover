﻿// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Public License (Ms-PL).
// Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
// All other rights reserved.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Diagnostics;
using Microsoft.Kinect;
using Coding4Fun.Kinect.Wpf;
using System.IO; 

namespace SkeletalTracking
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            serialPort1 =new System.IO.Ports.SerialPort();
            serialPort1.PortName = "COM6";
            serialPort1.BaudRate = 9600;
            serialPort1.Open();
           // serialPort1.Write("v"); // serial initialization debug
        }

        bool closing = false;
        const int skeletonCount = 6; 
        Skeleton[] allSkeletons = new Skeleton[skeletonCount];

        long timeC = 0;
        Stopwatch stopwatch = new Stopwatch();
        string filePathx = "C:\\Users\\Sakib\\Desktop\\hmmcode2\\workspace\\" + "test_rs_1.csv";
        //string filePathy = "C:\\Users\\Sakib\\Desktop\\hmmcode2\\workspace\\" + "sample4_y.csv";
        //string filePathz = "C:\\Users\\Sakib\\Desktop\\hmmcode2\\workspace\\" + "sample4_z.csv";
        StringBuilder sbx = new StringBuilder();
        StringBuilder sby = new StringBuilder();
        StringBuilder sbz = new StringBuilder();
        string delimiter = ",";
        int sample = 0;

        float kp = .95F;
        float kd = 0F;
        float prev_error = 0;
        int m1Speed = 150;
        int m2Speed = 150;
        System.IO.Ports.SerialPort serialPort1;

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            kinectSensorChooser1.KinectSensorChanged += new DependencyPropertyChangedEventHandler(kinectSensorChooser1_KinectSensorChanged);
            //this.sensor.SkeletonStream.TrackingMode = SkeletonTrackingMode.Seated;
            Debug.WriteLine("ok its fine :)");
            stopwatch.Start();
            if (!File.Exists(filePathx))
            {
                File.Create(filePathx).Close();
            }
            else
            {
                File.Delete(filePathx);
            }
            /*
            if (!File.Exists(filePathy))
            {
                File.Create(filePathy).Close();
            }
            else
            {
                File.Delete(filePathy);
            }
            if (!File.Exists(filePathz))
            {
                File.Create(filePathz).Close();
            }
            else
            {
                File.Delete(filePathz);
            }*/
        }

        void kinectSensorChooser1_KinectSensorChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            KinectSensor old = (KinectSensor)e.OldValue;

            StopKinect(old);

            KinectSensor sensor = (KinectSensor)e.NewValue;

            if (sensor == null)
            {
                return;
            }

            


            var parameters = new TransformSmoothParameters
            {
                //smoothing for kalman filter
                Smoothing = 0.3f,
                Correction = 0.0f,
                Prediction = 0.0f,
                JitterRadius = 1.0f,
                MaxDeviationRadius = 0.5f
            };
            sensor.SkeletonStream.Enable(parameters);


            sensor.SkeletonStream.Enable();
            sensor.SkeletonStream.TrackingMode = SkeletonTrackingMode.Seated;

            sensor.AllFramesReady += new EventHandler<AllFramesReadyEventArgs>(sensor_AllFramesReady);
            sensor.DepthStream.Enable(DepthImageFormat.Resolution640x480Fps30); 
            sensor.ColorStream.Enable(ColorImageFormat.RgbResolution640x480Fps30);

            try
            {
                sensor.Start();
            }
            catch (System.IO.IOException)
            {
                kinectSensorChooser1.AppConflictOccurred();
            }
        }

        void sensor_AllFramesReady(object sender, AllFramesReadyEventArgs e)
        {
            if (closing)
            {
                return;
            }

            //Get a skeleton
            Skeleton first =  GetFirstSkeleton(e);

            if (first == null)
            {
                return; 
            }



            //set scaled position
            ScalePosition(headImage, first.Joints[JointType.Head]);
            ScalePosition(leftEllipse, first.Joints[JointType.ElbowRight]);
            ScalePosition(rightEllipse, first.Joints[JointType.HandRight]);

            GetCameraPoint(first, e); 

        }

        void GetCameraPoint(Skeleton first, AllFramesReadyEventArgs e)
        {

            using (DepthImageFrame depth = e.OpenDepthImageFrame())
            {
                if (depth == null ||
                    kinectSensorChooser1.Kinect == null)
                {
                    return;
                }
                

                //Map a joint location to a point on the depth map
                //head
                DepthImagePoint headDepthPoint =
                    depth.MapFromSkeletonPoint(first.Joints[JointType.Head].Position);
                //left hand
                DepthImagePoint leftDepthPoint =
                    depth.MapFromSkeletonPoint(first.Joints[JointType.ElbowRight].Position);
                //right hand
                DepthImagePoint rightDepthPoint =
                    depth.MapFromSkeletonPoint(first.Joints[JointType.HandRight].Position);


                //Map a depth point to a point on the color image
                //head
                ColorImagePoint headColorPoint =
                    depth.MapToColorImagePoint(headDepthPoint.X, headDepthPoint.Y,
                    ColorImageFormat.RgbResolution640x480Fps30);
                //left hand
                ColorImagePoint leftColorPoint =
                    depth.MapToColorImagePoint(leftDepthPoint.X, leftDepthPoint.Y,
                    ColorImageFormat.RgbResolution640x480Fps30);
                //right hand
                ColorImagePoint rightColorPoint =
                    depth.MapToColorImagePoint(rightDepthPoint.X, rightDepthPoint.Y,
                    ColorImageFormat.RgbResolution640x480Fps30);
                //depthV.Text = leftDepthPoint.X + " " + leftDepthPoint.Y+" " + leftDepthPoint.;
                depthV.Text = first.Joints[JointType.HandRight].Position.X + " , " + first.Joints[JointType.HandRight].Position.Y + " ," +first.Joints[JointType.HandRight].Position.Z*100 + " ";
                //Set location
                CameraPosition(headImage, headColorPoint);
                CameraPosition(leftEllipse, leftColorPoint);
                CameraPosition(rightEllipse, rightColorPoint);
                
/*
                if(Stopwatch.GetTimestamp()-timeC>1000)
                {
                    timeC = Stopwatch.GetTimestamp();
                    time.Text = timeC + "";/// 1000 + "";
                }
                */
                if(stopwatch.ElapsedMilliseconds > 1000)
                {
                    time.Text = timeC++ + "";
                    //stopwatch.Stop();
                    stopwatch.Reset();
                    stopwatch.Start();
                }
                if(timeC>=4 && timeC<6)
                {
                    //time.Text.
                    //sbx.Append(string.Join(delimiter, first.Joints[JointType.HandRight].Position.X.ToString()));
                    if (sample %2 ==0)
                    {

                       /* if (sample % 10 == 0)
                        {
                            sbx.AppendLine();
                            sby.AppendLine();
                            sbz.AppendLine();
                        }*/
                        //rightColorPoint
                       // sbx.Append(first.Joints[JointType.HandRight].Position.X.ToString() + delimiter); //+" "+sample+"/"
                       // sby.Append(first.Joints[JointType.HandRight].Position.Y.ToString() + delimiter);
                       // sbz.Append(first.Joints[JointType.HandRight].Position.Z.ToString() + delimiter);

                        sbx.Append(rightColorPoint.X.ToString() + delimiter + rightColorPoint.Y.ToString() + delimiter + leftColorPoint.X.ToString() + delimiter + leftColorPoint.Y.ToString()); //+" "+sample+"/"
                        sbx.AppendLine();
                       // sby.Append(rightColorPoint.Y.ToString() + delimiter);
                       // sbz.Append(first.Joints[JointType.HandRight].Position.Z.ToString() + delimiter);
                        
                        
                        
                    }
                    sample++;

             

                }
                if (timeC == 8)
                {
                    File.AppendAllText(filePathx, sbx.ToString());
                   // File.AppendAllText(filePathy, sby.ToString());
                   // File.AppendAllText(filePathz, sbz.ToString());
                    //this.Close();
                }


                HVal.Text = rightColorPoint.X.ToString() + delimiter + rightColorPoint.Y.ToString() +delimiter + first.Joints[JointType.HandRight].Position.Z * 100;
                //double dis = first.Joints[JointType.HandRight].Position.Z * 100;
                PID(rightColorPoint.X, first.Joints[JointType.HandRight].Position.Z * 100); 
            }        
        }
        
       private void PID(int xLen,float depth) // Proportionate Differentiate Integral algorithm
       {
           //serialPort1.Write(xLen+","+xLen);
           
           if(xLen>640) xLen = 640;
           if(xLen<0) xLen =0;
           float error = (int)  (xLen - 320) * kp +(prev_error- xLen)*kd;
           prev_error = xLen;
           float motorOffset = kp * error;// +KD * (error - lastError);
           int temOff = (int)motorOffset;
           if(depth <140 ) 
           {
               serialPort1.Write("*");
               return;
           }
           if (temOff > 0)
           {
               serialPort1.Write(temOff + "#");
               Offset.Text = temOff + "#";
           }
           else
           {
               temOff = -1 * temOff;
               serialPort1.Write(temOff + "@");
               Offset.Text = temOff + "@";
           }
           
          

       }
       private void motorExec(int m1, int m2)
       {
            
       }

        Skeleton GetFirstSkeleton(AllFramesReadyEventArgs e)
        {
            using (SkeletonFrame skeletonFrameData = e.OpenSkeletonFrame())
            {
                if (skeletonFrameData == null)
                {
                    return null; 
                }

                
                skeletonFrameData.CopySkeletonDataTo(allSkeletons);

                //get the first tracked skeleton
                Skeleton first = (from s in allSkeletons
                                         where s.TrackingState == SkeletonTrackingState.Tracked
                                         select s).FirstOrDefault();

                return first;

            }
        }

        private void StopKinect(KinectSensor sensor)
        {
            if (sensor != null)
            {
                if (sensor.IsRunning)
                {
                    //stop sensor 
                    sensor.Stop();

                    //stop audio if not null
                    if (sensor.AudioSource != null)
                    {
                        sensor.AudioSource.Stop();
                    }


                }
            }
        }

        private void CameraPosition(FrameworkElement element, ColorImagePoint point)
        {
            //Divide by 2 for width and height so point is right in the middle 
            // instead of in top/left corner
            Canvas.SetLeft(element, point.X - element.Width / 2);
            Canvas.SetTop(element, point.Y - element.Height / 2);

        }

        private void ScalePosition(FrameworkElement element, Joint joint)
        {
            //convert the value to X/Y
            //Joint scaledJoint = joint.ScaleTo(1280, 720); 
            
            //convert & scale (.3 = means 1/3 of joint distance)
            Joint scaledJoint = joint.ScaleTo(1280, 720, .3f, .3f);

            Canvas.SetLeft(element, scaledJoint.Position.X);
            Canvas.SetTop(element, scaledJoint.Position.Y); 
            
        }


        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            closing = true; 
            StopKinect(kinectSensorChooser1.Kinect); 
        }



    }
}
